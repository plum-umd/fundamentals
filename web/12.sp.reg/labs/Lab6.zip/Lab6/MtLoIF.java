
// Represents an empty list of ImageFiles
public class MtLoIF implements ILoIF{

    public MtLoIF(){}

    // Does this empty list contain that ImageFile   
    public boolean contains(ImageFile that){ 
        return false;
    } 
} 
