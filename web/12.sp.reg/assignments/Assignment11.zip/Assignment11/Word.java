import java.util.*;

/** <code>Word</code> represents a word and its number of occurrences */
public class Word{
    /* ... FILL IN ... */

    public Word(String s){
        /* ... FILL IN ... */
    }
  
    /** Is this Word equal to the given Object */
    public boolean equals(Object obj){
        /* ... FILL IN ... */
        return true;
    }
  
    /** Produce this Word's hashCode */
    public int hashCode(){
        /* ... FILL IN ... */
        return 0;
    }
  
    /** Produce a String representation of this Word */
    public String toString(){
        return  "\n";
    }
}
