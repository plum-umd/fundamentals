package student;

import java.util.*;

public class Heapsort<T> extends SortingHeapSort<T>{
  
  public ArrayList<T> heapsort(ArrayList<T> alist, Comparator<T> comp) {
    // TODO Auto-generated method stub
    return alist;
  }
  
}