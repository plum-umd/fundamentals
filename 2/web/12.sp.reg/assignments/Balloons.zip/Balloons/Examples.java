import java.util.*;
import tester.*;
import colors.*;

/**
 * <p>The client class for the <code>{@link Balloon Balloon}</code> class 
 * and a class that represents three ballons ordered as given by the 
 * <code>Comparator</code>.</p>
 * <p>Tests for the methods for these classes.</p>
 * 
 * @since 7 March 2009
 * @author Viera K. Proulx 
 */
public class Examples{
  
  public Examples(){}
  
  /** a big red <code>{@link Balloon Balloon}</code> */
  Balloon b1 = new Balloon(100, 200, 25, new Red());

  /** a small blue <code>{@link Balloon Balloon}</code> */
  Balloon b2 = new Balloon(200, 100, 20, new Blue());
  
  /** a big green <code>{@link Balloon Balloon}</code> */
  Balloon b3 = new Balloon(200, 150, 30, new Green());
  
  /** a small red <code>{@link Balloon Balloon}</code> */
  Balloon b4 = new Balloon(200, 120, 22, new Red());

  /**
   * A method to construct an <code>ArrayList</code>
   * with four <code>{@link Balloon Balloon}</code>s 
   * 
   * @return an <code>ArrayList</code> with four 
   * <code>{@link Balloon Balloon}</code>s
   */
  public ArrayList<Balloon> makeArrBlist(){
    ArrayList<Balloon> arrlist = new ArrayList<Balloon>();
    arrlist.add(this.b1);
    arrlist.add(this.b2);
    arrlist.add(this.b3);
    arrlist.add(this.b4);
    return arrlist;
  }
  
  
  /** <code>{@link Balloon Balloon}</code> class tests: equality */  
  public void testEquality(Tester t){   
    t.checkExpect(this.b2, new Balloon(200, 100, 20, new Blue()), 
        "the same balloons OK");
    t.checkExpect(this.b2, this.b2, "the same balloons OK");
  }
       
  /** <code>{@link Balloon Balloon}</code> class tests: 
   * the <code>distanceFromTop</code> method */ 
  public void testDistanceFromTop(Tester t){   
    t.checkExpect(this.b1.distanceFromTop(), 200 - 25, "distanceFromTop 1");    
    t.checkExpect(this.b2.distanceFromTop(), 80, "distanceFromTop 2");  
  }
  
}