import colors.*;

/** 
 * A simple class to use for learning about classes and objects. 
 * 
 * @since  7 March 2009
 * @author Viera K. Proulx
 */

public class Balloon {
  
  /*-------------------------------------------------------------------------
   Member data 
   *-----------------------------------------------------------------------*/
  
  /** the center of the balloon */
  public int x;
  public int y;
  
  /** the radius of the balloon */
  public int radius;
  
  /** the color of the balloon */
  public IColor c;
  
  /*-------------------------------------------------------------------------
   Constructor
   *-----------------------------------------------------------------------*/
  /**
   * The full constructor
   */
  public Balloon (int x, int y, int radius, IColor color){
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.c = color;
  }
  
  /*-------------------------------------------------------------------------
   Methods 
   *-----------------------------------------------------------------------*/
   
  /** 
   * Compute the distance of this balloon from the top of window 
   * 
   * @return the distance to the top
   */
  int distanceFromTop(){
    return this.y - this.radius;
  } 
}
