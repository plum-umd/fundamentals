// to represent a list of books
interface ILoB{
	
}