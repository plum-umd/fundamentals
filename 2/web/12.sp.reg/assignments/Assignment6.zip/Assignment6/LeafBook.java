// a class to represent a leaf in a binary search tree
public class LeafBook extends ABSTBook{

  LeafBook(ICompareBooks comp){
		super(comp);
	}
	
}