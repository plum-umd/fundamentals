// a class to represent a node in a binary search tree
public class NodeBook extends ABSTBook{
	Book data;
	ABSTBook left;
	ABSTBook right;

	NodeBook(Book data, ABSTBook left, ABSTBook right){
		super(left.comp);
		this.data = data;
		this.left = left;
		this.right = right;
	}
	
}