// to represent a book
class Book{
  String title;
  String author;
  int year;
  
  Book(String title, String author, int year){
    this.title = title;
    this.author = author;
    this.year = year;
  }
}