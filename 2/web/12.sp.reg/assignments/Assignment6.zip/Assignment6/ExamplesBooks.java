import tester.*;

// examples and tests for lists of books
class ExamplesBooks{
  ExamplesBooks(){}
  
  Book eh1 = new Book("Old Man and the Sea", "EH", 1950);
  Book eh2 = new Book("Snows on Killimanjaro", "EH", 1954);
  Book eh3 = new Book("SAR", "EH", 1952);
  Book eh4 = new Book("AQOTWF", "EH", 1952);
  Book htdp = new Book("HtDP", "FFFK", 2001);
  Book sn = new Book("Shipping News", "EAP", 2000);
  Book dvc = new Book("DVC", "DB", 2000);
  
  
	
}