// to represent an empty list of books
class MtLoB implements ILoB{
  MtLoB(){}

}