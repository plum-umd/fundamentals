// to represent a nonempty list of books
class ConsLoB implements ILoB{
  Book first;
  ILoB rest;
  
  ConsLoB(Book first, ILoB rest){
    this.first = first;
    this.rest = rest;
  }
  
/* TEMPLATE:
   FIELDS:
   ... this.first ...    -- Book
   ... this.rest ...     -- ILoB
   
   METHODS:
 
   
   METHODS FOR FIELDS:
 
*/
  

}