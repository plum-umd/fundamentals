// to represent an abstract binary search tree
public abstract class ABSTBook{
  
	// the comparator that determines the tree ordering
	protected ICompareBooks comp;
	
	public ABSTBook(ICompareBooks comp){
		this.comp = comp;
	}
}