open module Lab6 {
    requires tester;
    requires javalib;
    requires java.desktop;
}