// Authors: partner1, partner2
// Lab 6

package edu.umd.cmsc132A;

import tester.Tester;
import javalib.worldimages.*;
import javalib.funworld.*;
import java.awt.Color;
import java.util.Random;

public class Lab6 { /* Intentionally blank; leave blank */ }

interface IBall {
    WorldImage draw();
    Posn location();
    IBall next();
}

// Ball class
class Ball implements IBall {
    static Integer BALLRADIUS = 20;
    Integer x;
    Integer y;
    Integer vx;
    Integer vy;

    Ball(Integer x, Integer y, Integer vx, Integer vy) {

    }

    // Draw this ball as a CircleImage
    public WorldImage draw() {
        return null;
    }

    // Return a Posn location of this ball
    public Posn location() {
        return null;
    }

    // Check if the ball is outside the BallWorld scene
    Boolean outside() {
        return false;
    }

    // Return the next ball
    public IBall next() {
        return new NoBall();
    }
}

// No Ball on the scene.
class NoBall implements IBall {
    public WorldImage draw() {
        return new CircleImage(0, OutlineMode.SOLID, Color.WHITE);
    }
    public Posn location() {
        return new Posn(0, 0);
    }
    public IBall next() {
        return this;
    }
}

class BallWorld extends World {
    static Random r = new Random();
    static Integer width = 640;
    static Integer height = 480;
    static Double tick = 0.1;
    IBall ball;

    BallWorld() {
        this(new NoBall());
    }

    BallWorld(IBall ball) {
        this.ball = ball;
    }

    // Create a world with the ball in the given location, with random X and Y speeds.
    public World onMouseClicked(Posn mouse) {
        return null;
    }

    // Tick the world's ball and return a new BallWorld.
    public World onTick() {
        return null;
    }

    // Place the ball's image on the scene.
    public WorldScene makeScene() {
        WorldScene scene = new WorldScene(this.width, this.height);
        scene = scene.placeImageXY(new RectangleImage(this.width, this.height, OutlineMode.SOLID, Color.WHITE), this.width / 2, this.height / 2);
        // Place ball on scene with placeImageXY
        return scene;
    }
}

//-----------------------------------------------------------------------------
// Tests

class Tests {
    Boolean testBallTick(Tester t) {
        BallWorld w = new BallWorld();
        return w.bigBang(BallWorld.width, BallWorld.height, BallWorld.tick);
    }
}